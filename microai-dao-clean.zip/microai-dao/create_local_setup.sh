#!/bin/bash

# MicroAI DAO LLC - Complete Local Setup Script
# This creates everything locally without requiring GitHub first

echo "🚀 Creating MicroAI DAO locally..."
echo "=================================="

# Create project directory
PROJECT_DIR="$HOME/microai-dao-local"
echo "📁 Creating project at: $PROJECT_DIR"

if [ -d "$PROJECT_DIR" ]; then
    echo "⚠️  Directory exists. Removing old version..."
    rm -rf "$PROJECT_DIR"
fi

mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR"

# Create directory structure
echo "📁 Creating directory structure..."
mkdir -p programs/governance/src
mkdir -p programs/membership/src
mkdir -p scripts

echo "✅ Directory structure created"
echo ""

echo "🔧 Next steps:"
echo "1. Run the installation script to install tools"
echo "2. Copy the smart contract files"
echo "3. Test and deploy"
echo ""
echo "📍 Project location: $PROJECT_DIR"

