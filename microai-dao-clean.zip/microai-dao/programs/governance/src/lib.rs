//! MicroAI DAO LLC Governance Program
//! 
//! This program implements the minimum governance requirements for a Wyoming DAO LLC
//! with EXECAI as a stakeholder.

use borsh::{BorshDeserialize, BorshSerialize};
use solana_program::{
    account_info::{next_account_info, AccountInfo},
    entrypoint,
    entrypoint::ProgramResult,
    msg,
    program_error::ProgramError,
    pubkey::Pubkey,
    clock::Clock,
    sysvar::Sysvar,
};

/// Program entrypoint
entrypoint!(process_instruction);

/// Program instructions
#[derive(BorshSerialize, BorshDeserialize, Debug)]
pub enum GovernanceInstruction {
    /// Initialize the governance program
    /// 
    /// Accounts expected:
    /// 0. `[writable]` Governance state account
    /// 1. `[]` Rent sysvar
    Initialize {
        /// Percentage of votes required for quorum (0-100)
        quorum_percentage: u8,
    },

    /// Submit a new proposal
    /// 
    /// Accounts expected:
    /// 0. `[]` Governance state account
    /// 1. `[writable]` Proposal account
    /// 2. `[signer]` Proposer account
    SubmitProposal {
        /// Description of the proposal
        description: String,
    },

    /// Vote on a proposal
    /// 
    /// Accounts expected:
    /// 0. `[]` Governance state account
    /// 1. `[writable]` Proposal account
    /// 2. `[signer]` Voter account
    /// 3. `[]` Member account (to verify voting power)
    Vote {
        /// Whether to approve the proposal
        approve: bool,
    },

    /// Execute a proposal
    /// 
    /// Accounts expected:
    /// 0. `[]` Governance state account
    /// 1. `[writable]` Proposal account
    /// 2. `[signer]` Executor account
    ExecuteProposal,

    /// Log an action for transparency
    /// 
    /// Accounts expected:
    /// 0. `[writable]` Log account
    /// 1. `[signer]` Actor account
    LogAction {
        /// Description of the action
        action: String,
    },
}

/// Governance state
#[derive(BorshSerialize, BorshDeserialize, Debug)]
pub struct Governance {
    /// Number of proposals created
    pub proposal_count: u64,
    /// Percentage of votes required for quorum (0-100)
    pub quorum_percentage: u8,
}

/// Proposal state
#[derive(BorshSerialize, BorshDeserialize, Debug)]
pub struct Proposal {
    /// Unique proposal ID
    pub id: u64,
    /// Description of the proposal
    pub description: String,
    /// Whether the proposal has been approved
    pub approved: bool,
    /// Whether the proposal has been executed
    pub executed: bool,
    /// Number of yes votes
    pub yes_votes: u64,
    /// Number of no votes
    pub no_votes: u64,
    /// Timestamp when the proposal was created
    pub created_at: i64,
}

/// Action log
#[derive(BorshSerialize, BorshDeserialize, Debug)]
pub struct ActionLog {
    /// Description of the action
    pub action: String,
    /// Account that performed the action
    pub actor: Pubkey,
    /// Timestamp when the action was performed
    pub timestamp: i64,
}

/// Program errors
#[derive(Debug, thiserror::Error)]
pub enum GovernanceError {
    #[error("Invalid instruction")]
    InvalidInstruction,
    
    #[error("Proposal already exists")]
    ProposalAlreadyExists,
    
    #[error("Proposal not found")]
    ProposalNotFound,
    
    #[error("Proposal already executed")]
    ProposalAlreadyExecuted,
    
    #[error("Quorum not reached")]
    QuorumNotReached,
    
    #[error("Not authorized")]
    NotAuthorized,
}

impl From<GovernanceError> for ProgramError {
    fn from(e: GovernanceError) -> Self {
        ProgramError::Custom(e as u32)
    }
}

/// Process program instruction
pub fn process_instruction(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    instruction_data: &[u8],
) -> ProgramResult {
    let instruction = GovernanceInstruction::try_from_slice(instruction_data)?;
    
    match instruction {
        GovernanceInstruction::Initialize { quorum_percentage } => {
            process_initialize(program_id, accounts, quorum_percentage)
        }
        GovernanceInstruction::SubmitProposal { description } => {
            process_submit_proposal(program_id, accounts, description)
        }
        GovernanceInstruction::Vote { approve } => {
            process_vote(program_id, accounts, approve)
        }
        GovernanceInstruction::ExecuteProposal => {
            process_execute_proposal(program_id, accounts)
        }
        GovernanceInstruction::LogAction { action } => {
            process_log_action(program_id, accounts, action)
        }
    }
}

/// Process Initialize instruction
fn process_initialize(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    quorum_percentage: u8,
) -> ProgramResult {
    let account_info_iter = &mut accounts.iter();
    let governance_account = next_account_info(account_info_iter)?;
    
    // Ensure quorum percentage is valid
    if quorum_percentage > 100 {
        return Err(ProgramError::InvalidArgument);
    }
    
    let governance = Governance {
        proposal_count: 0,
        quorum_percentage,
    };
    
    governance.serialize(&mut *governance_account.data.borrow_mut())?;
    
    msg!("Governance initialized with quorum percentage: {}", quorum_percentage);
    Ok(())
}

/// Process SubmitProposal instruction
fn process_submit_proposal(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    description: String,
) -> ProgramResult {
    let account_info_iter = &mut accounts.iter();
    let governance_account = next_account_info(account_info_iter)?;
    let proposal_account = next_account_info(account_info_iter)?;
    let proposer_account = next_account_info(account_info_iter)?;
    
    // Ensure proposer signed the transaction
    if !proposer_account.is_signer {
        return Err(GovernanceError::NotAuthorized.into());
    }
    
    // Load governance state
    let mut governance = Governance::try_from_slice(&governance_account.data.borrow())?;
    
    // Create proposal
    let proposal = Proposal {
        id: governance.proposal_count,
        description,
        approved: false,
        executed: false,
        yes_votes: 0,
        no_votes: 0,
        created_at: Clock::get()?.unix_timestamp,
    };
    
    // Increment proposal count
    governance.proposal_count += 1;
    
    // Save states
    proposal.serialize(&mut *proposal_account.data.borrow_mut())?;
    governance.serialize(&mut *governance_account.data.borrow_mut())?;
    
    msg!("Proposal submitted with ID: {}", proposal.id);
    Ok(())
}

/// Process Vote instruction
fn process_vote(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    approve: bool,
) -> ProgramResult {
    let account_info_iter = &mut accounts.iter();
    let _governance_account = next_account_info(account_info_iter)?;
    let proposal_account = next_account_info(account_info_iter)?;
    let voter_account = next_account_info(account_info_iter)?;
    let member_account = next_account_info(account_info_iter)?;
    
    // Ensure voter signed the transaction
    if !voter_account.is_signer {
        return Err(GovernanceError::NotAuthorized.into());
    }
    
    // Load proposal
    let mut proposal = Proposal::try_from_slice(&proposal_account.data.borrow())?;
    
    // Ensure proposal hasn't been executed
    if proposal.executed {
        return Err(GovernanceError::ProposalAlreadyExecuted.into());
    }
    
    // In a real implementation, we would load the member's voting power from the member account
    // For simplicity, we'll assume each member has 1 vote
    // In a full implementation, EXECAI would have its own voting power
    
    // Record vote
    if approve {
        proposal.yes_votes += 1;
        msg!("Vote recorded: YES");
    } else {
        proposal.no_votes += 1;
        msg!("Vote recorded: NO");
    }
    
    // Save proposal state
    proposal.serialize(&mut *proposal_account.data.borrow_mut())?;
    
    Ok(())
}

/// Process ExecuteProposal instruction
fn process_execute_proposal(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
) -> ProgramResult {
    let account_info_iter = &mut accounts.iter();
    let governance_account = next_account_info(account_info_iter)?;
    let proposal_account = next_account_info(account_info_iter)?;
    let executor_account = next_account_info(account_info_iter)?;
    
    // Ensure executor signed the transaction
    if !executor_account.is_signer {
        return Err(GovernanceError::NotAuthorized.into());
    }
    
    // Load governance and proposal
    let governance = Governance::try_from_slice(&governance_account.data.borrow())?;
    let mut proposal = Proposal::try_from_slice(&proposal_account.data.borrow())?;
    
    // Ensure proposal hasn't been executed
    if proposal.executed {
        return Err(GovernanceError::ProposalAlreadyExecuted.into());
    }
    
    // Check if quorum is reached
    let total_votes = proposal.yes_votes + proposal.no_votes;
    if total_votes == 0 {
        return Err(GovernanceError::QuorumNotReached.into());
    }
    
    let yes_percentage = (proposal.yes_votes * 100) / total_votes;
    if yes_percentage < governance.quorum_percentage as u64 {
        return Err(GovernanceError::QuorumNotReached.into());
    }
    
    // Mark proposal as approved and executed
    proposal.approved = true;
    proposal.executed = true;
    
    // Save proposal state
    proposal.serialize(&mut *proposal_account.data.borrow_mut())?;
    
    msg!("Proposal executed with ID: {}", proposal.id);
    Ok(())
}

/// Process LogAction instruction
fn process_log_action(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    action: String,
) -> ProgramResult {
    let account_info_iter = &mut accounts.iter();
    let log_account = next_account_info(account_info_iter)?;
    let actor_account = next_account_info(account_info_iter)?;
    
    // Ensure actor signed the transaction
    if !actor_account.is_signer {
        return Err(GovernanceError::NotAuthorized.into());
    }
    
    // Create log entry
    let log_entry = ActionLog {
        action,
        actor: *actor_account.key,
        timestamp: Clock::get()?.unix_timestamp,
    };
    
    // Save log entry
    log_entry.serialize(&mut *log_account.data.borrow_mut())?;
    
    msg!("Action logged by: {}", actor_account.key);
    Ok(())
}

